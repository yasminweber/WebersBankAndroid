package com.example.webersbank

class Transaction {
    constructor(id: Long, descricao: String,
                dinheiros: Float) {
        this.id = id
        this.descricao = descricao
        this.dinheiros = dinheiros
    }

    constructor(descricao: String, dinheiros: Float) {
        this.descricao = descricao
        this.dinheiros = dinheiros
    }

    var id = 0L
    var descricao = ""
    var dinheiros = 0F
}