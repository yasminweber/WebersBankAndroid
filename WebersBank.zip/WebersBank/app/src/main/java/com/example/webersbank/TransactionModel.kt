package com.example.webersbank

import android.content.Context

class TransactionModel private constructor() {

    var transactions = ArrayList<Transaction>()
    companion object{
        val instance = TransactionModel()
    }

    private lateinit var context:Context
    private lateinit var database:TransactionsDatabase

    fun setContext(context: Context){
        this.context = context
        database = TransactionsDatabase(context)
        transactions = database.retrieveTransaction()
    }

    fun addNewTransaction(transaction: Transaction){
        val id = database.createTransaction(transaction)
//        if(id > 0){
           transactions = database.retrieveTransaction()
//        }else{
//            TODO("error")
//        }
    }
}