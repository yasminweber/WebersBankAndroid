package com.example.webersbank

import android.graphics.Color
import android.support.v7.widget.CardView
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class TransactionAdapter :

    RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {
    inner class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        var textViewDescricao: TextView
        var textViewDinheiros: TextView
        var cardView: CardView

        init {
            textViewDescricao = itemView.findViewById(R.id.card_description)
            textViewDinheiros = itemView.findViewById(R.id.card_money)
            cardView = itemView.findViewById(R.id.card__view)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.transacao_view,
                parent, false
            )
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val transaction = TransactionModel.instance.transactions[position]
        holder.textViewDescricao.text = transaction.descricao
        holder.textViewDinheiros.text = transaction.dinheiros.toString()
        if (transaction.dinheiros >= 0) {
            // Verde
            holder.cardView.setCardBackgroundColor(Color.parseColor("#99d0c8"))
            holder.textViewDescricao.setTextColor(Color.parseColor("#00574B"))
            holder.textViewDinheiros.setTextColor(Color.parseColor("#00574B"))
        } else {
            // Vermelho
            holder.cardView.setCardBackgroundColor(Color.parseColor("#ffb7b2"))
            holder.textViewDescricao.setTextColor(Color.parseColor("#890900"))
            holder.textViewDinheiros.setTextColor(Color.parseColor("#890900"))
        }
    }

    override fun getItemCount(): Int {
        return TransactionModel.instance.transactions.size
    }
}


