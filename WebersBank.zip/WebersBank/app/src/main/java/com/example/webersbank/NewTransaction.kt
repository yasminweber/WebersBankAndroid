package com.example.webersbank

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.EditText

class NewTransaction : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.new_transaction)

    }

    fun buttonDespesa(view:View){
        val descricao = findViewById<EditText>(R.id.textDescricao)
        val dinheiro = findViewById<EditText>(R.id.textDinheiros)
        Log.d("buttonDespesa",dinheiro.text.toString())
        val dinheiroNegativo = (dinheiro.text.toString().toFloat() * -1.0f)


        TransactionModel.instance.addNewTransaction(Transaction(descricao = descricao.text.toString(), dinheiros = dinheiroNegativo))
        finish()
    }

    fun buttonReceita(view:View){
        val descricao = findViewById<EditText>(R.id.textDescricao)
        val dinheiro = findViewById<EditText>(R.id.textDinheiros)
        Log.d("buttonReceita",dinheiro.text.toString())

        TransactionModel.instance.addNewTransaction(Transaction(descricao = descricao.text.toString(), dinheiros = dinheiro.text.toString().toFloat()))
        finish()
    }
}