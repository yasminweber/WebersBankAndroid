package com.example.webersbank

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.widget.Button
import android.widget.TextView

class Principal : AppCompatActivity() {

    lateinit var recyclerView:RecyclerView
    lateinit var transactionAdapter: TransactionAdapter
    private lateinit var context:Context
    private lateinit var database:TransactionsDatabase
    var transactions = ArrayList<Transaction>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.principal)
        TransactionModel.instance.setContext(this)

        val buttonNew = findViewById<Button>(R.id.button_newTransaction)
        buttonNew.setOnClickListener {
            val intent = Intent(this, NewTransaction::class.java)
            startActivity(intent)
        }

        recyclerView = findViewById(R.id.recycleView)

        transactionAdapter = TransactionAdapter()

        recyclerView.adapter = transactionAdapter
        recyclerView.layoutManager =
            LinearLayoutManager(this)

        loadSaldo(this)

    }

    override fun onResume() {
        super.onResume()
        transactionAdapter.notifyDataSetChanged()
        loadSaldo(this)
    }

    fun loadSaldo(context: Context){
        this.context = context
        database = TransactionsDatabase(context)
        transactions = database.retrieveTransaction()
        var saldo:Float = 0.toFloat()
        for (transaction in transactions) {
            saldo += transaction.dinheiros
            Log.d("transacaaaoo", saldo.toString())
        }
        var valor = findViewById<TextView>(R.id.valor)
        valor.text = "R$ " + saldo.toString()
        Log.d("óia o saldo", saldo.toString())

    }
}