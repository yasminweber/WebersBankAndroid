package com.example.webersbank

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TransactionsDatabase(context:Context):

    SQLiteOpenHelper(context,DB_NAME,null,DB_VERSION) {
        companion object{
            private const val DB_NAME = "transactions.sqlite"
            private const val DB_VERSION = 1
            private const val DB_TABLE = "transacao"
            private const val COL_ID = "id"
            private const val COL_DESCRICAO = "descricao"
            private const val COL_DINHEIROS = "dinheiros"
        }

        override fun onCreate(sqliteDatabase: SQLiteDatabase?) {
            val query = "create table if not exists $DB_TABLE (" +
                    "$COL_ID integer primary key autoincrement," +
                    "$COL_DESCRICAO text," +
                    "$COL_DINHEIROS double)"
            sqliteDatabase?.execSQL(query)
        }

        override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
            TODO("Not yet implemented")
        }

        fun createTransaction(transaction: Transaction) : Long{
            val database = writableDatabase
            val values = ContentValues()
            values.put(COL_DESCRICAO,transaction.descricao)
            values.put(COL_DINHEIROS,transaction.dinheiros)
            val id = database.insert(DB_TABLE,null,
                values)
            database.close()
            return id
        }

//        fun updateTransaction(transaction:Transaction) : Int{
//            val database = writableDatabase
//            val values = ContentValues()
//            values.put(COL_DESCRICAO,transaction.descricao)
//            values.put(COL_DINHEIROS,transaction.dinheiros)
//            val count = database.update(DB_TABLE,
//                values,"$COL_ID =? ",
//                arrayOf(transaction.id.toString()))
//            database.close()
//            return count
//        }
//
//        fun removeTransaction(transaction:Transaction) : Int{
//            val database = writableDatabase
//            val count = database.delete(DB_TABLE,
//                "$COL_ID =? ",
//                arrayOf(transaction.id.toString()))
//            database.close()
//            return count
//        }

        fun retrieveTransaction():ArrayList<Transaction>{
            var transactions = ArrayList<Transaction>()
            val cursor = readableDatabase.query(DB_TABLE,
                null,null,null,null,
                null,null)
            if(cursor.moveToFirst()){
                do{
                    val id = cursor.getLong(
                        cursor.getColumnIndexOrThrow(COL_ID))
                    val descricao = cursor.getString(
                        cursor.getColumnIndexOrThrow(COL_DESCRICAO))
                    val dinheiros = cursor.getFloat(
                        cursor.getColumnIndexOrThrow(COL_DINHEIROS))
                    transactions.add(Transaction(id,descricao, dinheiros))
                }while (cursor.moveToNext())
            }
            readableDatabase.close()
            return transactions
        }
    }
